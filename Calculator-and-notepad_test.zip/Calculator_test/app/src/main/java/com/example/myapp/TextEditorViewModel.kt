package com.example.myapp

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class EditorState(
    val textContent: String = "",
    val isSaving: Boolean = false,
    val statusMessage: String? = null,
    val isBold: Boolean = false,
    val isItalic: Boolean = false,
    val fontSize: Float = 16f,
    val minFontSize: Float = 12f,
    val maxFontSize: Float = 30f,
)

class TextEditorViewModel : ViewModel() {
    private val _state = MutableStateFlow(EditorState())
    val state: StateFlow<EditorState> = _state.asStateFlow()

    /**
     * Updates the text content whenever the user types.
     */
    fun updateTextContent(newText: String) {
        _state.update {
            it.copy(
                textContent = newText,
                statusMessage = null // Clear status when typing
            )
        }
    }

    fun toggleBold() {
        _state.update { it.copy(isBold = !it.isBold) }
    }

    fun toggleItalic() {
        _state.update { it.copy(isItalic = !it.isItalic) }
    }

    fun increaseFontSize() {
        _state.update {
            it.copy(
                fontSize = (it.fontSize + 2f).coerceAtMost(it.maxFontSize)
            )
        }
    }

    fun decreaseFontSize() {
        _state.update {
            it.copy(
                fontSize = (it.fontSize - 2f).coerceAtLeast(it.minFontSize)
            )
        }
    }
}

package com.example.myapp

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = AppRoutes.MENU
    ) {
        composable(route = AppRoutes.MENU) {
            MenuScreen(navController = navController)
        }

        composable(route = AppRoutes.CALCULATOR) {
            val calculatorViewModel: CalculatorViewModel = viewModel()
            Calculator(navController = navController, viewModel = calculatorViewModel)
        }

        composable(route = AppRoutes.TEXT_EDITOR) {
            val textEditorViewModel: TextEditorViewModel = viewModel()
            TextEditor(navController = navController, viewModel = textEditorViewModel)
        }
    }
}
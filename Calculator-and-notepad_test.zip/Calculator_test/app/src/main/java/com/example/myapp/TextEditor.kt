// in TextEditor.kt
package com.example.myapp

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController


@Composable
fun TextEditor(
    navController: NavController,
    viewModel: TextEditorViewModel
) {
    val uiState by viewModel.state.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly, // Menyebarkan tombol
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (uiState.isBold) {
                Button(
                    onClick = { viewModel.toggleBold() },
                ) {
                    Text(
                        text = "B",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            } else {
                OutlinedButton(
                    onClick = { viewModel.toggleBold() },
                ) {
                    Text(
                        text = "B",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }

            if (uiState.isItalic) {
                Button(
                    onClick = { viewModel.toggleItalic() },
                ) {
                    Text(
                        text = "I",
                        fontStyle = FontStyle.Italic,
                        fontSize = 18.sp
                    )
                }
            } else {
                OutlinedButton(
                    onClick = { viewModel.toggleItalic() },
                ) {
                    Text(
                        text = "I",
                        fontStyle = FontStyle.Italic,
                        fontSize = 18.sp
                    )
                }
            }
            OutlinedButton(onClick = { viewModel.decreaseFontSize() }) {
                Text(text = "-", fontSize = 20.sp)
            }

            Text(
                text = "${uiState.fontSize.toInt()} sp",
                modifier = Modifier.padding(horizontal = 8.dp),
                fontSize = 16.sp
            )

            OutlinedButton(onClick = { viewModel.increaseFontSize() }) {
                Text(text = "+", fontSize = 20.sp)
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = uiState.textContent,
            onValueChange = { newText ->
                viewModel.updateTextContent(newText)
            },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),

            textStyle = TextStyle(
                fontWeight = if (uiState.isBold) FontWeight.Bold else FontWeight.Normal,
                fontStyle = if (uiState.isItalic) FontStyle.Italic else FontStyle.Normal,
                fontSize = uiState.fontSize.sp
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { navController.navigate(AppRoutes.MENU) },
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text("Back to Menu")
        }
    }
}